import { expect, test } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';
import { api } from './api-url.js';

test('editor plan actions share the garden bar, preserve state and fit narrow screens', async ({ page, request }) => {
  const garden = await (await request.post(`${api}/gardens`, { data: { name: `E2E toolbar ${Date.now()}` } })).json();
  try {
    await page.goto(`/gardens/${garden.id}`);
    await expect(page.getByTestId('save-status')).toHaveText('保存済み');
    const bar = page.locator('.document-bar');
    await expect(bar.getByRole('group', { name: '庭の計画と購入' }).getByRole('button')).toHaveCount(5);
    await expect(page.locator('.editor-shell > .plan-actions')).toHaveCount(0);
    for (const width of [1440, 1280, 1100, 1024, 768, 390, 320]) {
      await page.setViewportSize({ width, height: 960 });
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
      const bounds = await bar.boundingBox();
      for (const button of await bar.getByRole('button').all()) {
        const item = await button.boundingBox();
        expect(item!.x).toBeGreaterThanOrEqual(bounds!.x);
        expect(item!.x + item!.width).toBeLessThanOrEqual(bounds!.x + bounds!.width + 1);
      }
      if (width >= 1280) expect(bounds!.height).toBeLessThanOrEqual(70);
    }
    await page.setViewportSize({ width: 1440, height: 960 });
    await bar.getByRole('button', { name: '数量・施工範囲', exact: true }).click();
    await expect(page.getByRole('dialog', { name: '配置数量・施工範囲' })).toContainText('配置したものはありません');
    await page.keyboard.press('Escape');
    await expect(bar.getByRole('button', { name: '数量・施工範囲', exact: true })).toBeFocused();
    await bar.getByRole('button', { name: '植物候補を相談', exact: true }).click();
    await page.getByRole('combobox', { name: '日照', exact: true }).selectOption('半日陰');
    await page.getByRole('button', { name: '候補を確認', exact: true }).click();
    await expect(page.getByRole('dialog')).toContainText('アオキ・ヤブラン');
    await page.keyboard.press('Escape');
    await page.getByRole('button', { name: '上から見る', exact: true }).click();
    await page.getByTestId('asset-tree_oak').click();
    const canvas = await page.locator('[data-testid="garden-canvas"] canvas').boundingBox();
    await page.mouse.click(canvas!.x + canvas!.width / 2, canvas!.y + canvas!.height / 2);
    await expect(page.getByTestId('model-loaded')).toHaveText('読み込み済み: 1 / 1');
    await page.keyboard.press('Escape');
    await bar.getByRole('button', { name: '数量・施工範囲', exact: true }).click();
    await page.getByLabel('木の配置個数').fill('2');
    await expect(page.getByLabel('木の配置個数')).toHaveValue('2');
    await page.keyboard.press('Escape');
    await bar.getByRole('button', { name: '配置したものから商品を探す', exact: true }).click();
    await expect(page.getByRole('dialog', { name: '変更を保存して進みますか？' })).toBeVisible();
    await page.getByRole('button', { name: '取消', exact: true }).click();
    await expect(page).toHaveURL(new RegExp(`/gardens/${garden.id}$`));
    await bar.getByTestId('save-garden').click();
    await expect(bar.getByTestId('save-status')).toHaveText('保存済み');
    await page.reload();
    await expect(page.getByTestId('model-loaded')).toHaveText('読み込み済み: 2 / 2');
    const saved = await (await request.get(`${api}/gardens/${garden.id}`)).json();
    expect(saved.objects).toHaveLength(2);
    await mkdir('artifacts/e2e', { recursive: true });
    await writeFile('artifacts/e2e/editor-toolbar-reloaded.json', JSON.stringify(saved, null, 2));
    await page.screenshot({ path: 'artifacts/e2e/editor-toolbar-reloaded.png' });
    await bar.getByRole('button', { name: '完成イメージを確認', exact: true }).click();
    await expect(page.getByRole('dialog', { name: '庭の完成イメージ' }).locator('img')).toBeVisible();
    await page.keyboard.press('Escape');
    await bar.getByRole('button', { name: 'ECへ戻る', exact: true }).click();
    await expect(page).toHaveURL('http://127.0.0.1:5186/');
  } finally {
    expect((await request.delete(`${api}/gardens/${garden.id}`)).status()).toBe(204);
  }
});
