import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { expect, test, type Page, type APIRequestContext } from '@playwright/test';
import type { GardenDocument } from '../frontend/src/types/garden.js';

const apiBase = 'http://127.0.0.1:18080/api';
const artifactDirectory = resolve('artifacts/e2e');
let createdGardenIds: string[] = [];

test.beforeEach(() => {
  createdGardenIds = [];
});

test.afterEach(async ({ request }) => {
  for (const id of createdGardenIds) {
    const response = await request.delete(`${apiBase}/gardens/${id}`);
    expect([204, 404]).toContain(response.status());
  }
});

async function createGarden(page: Page, name: string): Promise<string> {
  await page.goto('/');
  await page.getByLabel('庭の名前').fill(name);
  await page.getByRole('button', { name: '庭を作成' }).click();
  await page.waitForURL(/\/gardens\//);
  const id = new URL(page.url()).pathname.split('/').at(-1);
  if (!id) throw new Error('作成後に庭IDを取得できませんでした。');
  createdGardenIds.push(id);
  await expect(page.getByTestId('save-status')).toHaveText('保存済み');
  return id;
}

async function placeTree(page: Page, x = 0.5, y = 0.5): Promise<void> {
  await page.getByRole('button', { name: '上から見る' }).click();
  await page.getByTestId('asset-tree_oak').click();
  const canvas = page.locator('[data-testid="garden-canvas"] canvas');
  const bounds = await canvas.boundingBox();
  if (!bounds) throw new Error('3Dキャンバスが表示されていません。');
  await page.mouse.click(bounds.x + bounds.width * x, bounds.y + bounds.height * y);
  await expect(page.getByTestId('object-row-0')).toBeVisible();
  await expect(page.getByTestId('model-loaded')).toHaveText('読み込み済み: 1 / 1');
}

async function gardenJson(request: APIRequestContext, id: string): Promise<GardenDocument> {
  const response = await request.get(`${apiBase}/gardens/${id}`);
  expect(response.ok()).toBeTruthy();
  return await response.json() as GardenDocument;
}

async function saveGardenArtifact(request: APIRequestContext, id: string, fileName: string): Promise<GardenDocument> {
  const document = await gardenJson(request, id);
  await mkdir(artifactDirectory, { recursive: true });
  await writeFile(resolve(artifactDirectory, fileName), `${JSON.stringify(document, null, 2)}\n`, 'utf8');
  return document;
}

test('A. 庭作成からGLB配置・変形・保存・再読み込みまで', async ({ page, request }) => {
  const name = `E2E roundtrip ${Date.now()}`;
  const id = await createGarden(page, name);
  await placeTree(page);

  const canvas = page.locator('[data-testid="garden-canvas"] canvas');
  const bounds = await canvas.boundingBox();
  if (!bounds) throw new Error('3Dキャンバスが表示されていません。');
  const initialX = Number(await page.getByTestId('position-x').inputValue());
  const initialZ = Number(await page.getByTestId('position-z').inputValue());
  await page.mouse.move(bounds.x + bounds.width / 2 + 35, bounds.y + bounds.height / 2);
  await page.mouse.down();
  await page.mouse.move(bounds.x + bounds.width / 2 + 75, bounds.y + bounds.height / 2 + 8, { steps: 6 });
  await page.mouse.up();
  await expect.poll(async () => {
    const currentX = Number(await page.getByTestId('position-x').inputValue());
    const currentZ = Number(await page.getByTestId('position-z').inputValue());
    return Math.abs(currentX - initialX) + Math.abs(currentZ - initialZ);
  }).toBeGreaterThan(0.1);

  await page.getByTestId('rotation-y').fill('30');
  await page.getByTestId('uniform-scale').fill('1.25');
  await expect(page.getByTestId('rotation-y')).toHaveValue('30');
  await expect(page.getByTestId('uniform-scale')).toHaveValue('1.25');
  const savedX = Number(await page.getByTestId('position-x').inputValue());
  await page.getByRole('button', { name: '上から見る' }).click();
  await page.getByTestId('save-garden').click();
  await expect(page.getByTestId('save-status')).toHaveText('保存済み');
  const stored = await saveGardenArtifact(request, id, 'garden-roundtrip.json');
  expect(stored.revision).toBe(1);
  expect(stored.objects).toHaveLength(1);
  expect(stored.objects[0].position.x).toBeCloseTo(savedX, 2);
  expect(stored.objects[0].rotation.y).toBeCloseTo(Math.PI / 6, 5);
  expect(stored.objects[0].scale).toEqual({ x: 1.25, y: 1.25, z: 1.25 });

  await page.reload();
  await expect(page.getByTestId('model-loaded')).toHaveText('読み込み済み: 1 / 1');
  await expect(page.getByTestId('position-x')).toHaveValue(String(Number(savedX.toFixed(2))));
  await expect(page.getByTestId('rotation-y')).toHaveValue('30');
  await expect(page.getByTestId('uniform-scale')).toHaveValue('1.25');
  await expect(page.getByTestId('object-row-0')).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: '上から見る' }).click();
  await page.screenshot({ path: resolve(artifactDirectory, 'garden-roundtrip.png'), fullPage: true });
  await test.info().attach('garden-roundtrip.json', {
    body: JSON.stringify(stored, null, 2),
    contentType: 'application/json',
  });

  await page.getByRole('button', { name: '← 庭一覧' }).click();
  await page.waitForURL('/');
  const card = page.locator('.garden-card').filter({ hasText: name });
  await expect(card.locator('.garden-card-open')).toBeVisible();
  await card.locator('.garden-card-open').click();
  await expect(page.locator('h1')).toHaveText(name);
  await expect(page.getByTestId('model-loaded')).toHaveText('読み込み済み: 1 / 1');
  await expect(page.getByTestId('position-x')).toHaveValue(String(Number(savedX.toFixed(2))));

  const deleteButton = card.getByRole('button', { name: `${name}を削除` });
  page.once('dialog', (dialog) => dialog.dismiss());
  await deleteButton.click();
  await expect(card.locator('.garden-card-open')).toBeVisible();
  expect((await request.get(`${apiBase}/gardens/${id}`)).status()).toBe(200);

  page.once('dialog', (dialog) => dialog.accept());
  await deleteButton.click();
  await expect(card).toHaveCount(0);
  expect((await request.get(`${apiBase}/gardens/${id}`)).status()).toBe(404);
});

test('B. 同一GLBの配置、独立移動、複製、削除', async ({ page, request }) => {
  const id = await createGarden(page, `E2E independent ${Date.now()}`);
  await placeTree(page, 0.42, 0.5);
  await page.getByTestId('asset-tree_oak').click();
  const canvas = page.locator('[data-testid="garden-canvas"] canvas');
  const bounds = await canvas.boundingBox();
  if (!bounds) throw new Error('3Dキャンバスが表示されていません。');
  await page.mouse.click(bounds.x + bounds.width * 0.70, bounds.y + bounds.height * 0.5);
  await expect(page.getByTestId('object-row-1')).toBeVisible();
  await expect(page.getByTestId('model-loaded')).toHaveText('読み込み済み: 2 / 2');
  await page.getByTestId('save-garden').click();
  await expect(page.getByTestId('save-status')).toHaveText('保存済み');

  const original = await gardenJson(request, id);
  const originalIds = original.objects.map((object) => object.id);
  const secondPositionBefore = structuredClone(original.objects[1].position);
  await page.getByTestId('object-row-0').click();
  await page.getByTestId('position-x').fill('-1.5');
  await expect(page.getByTestId('position-x')).toHaveValue('-1.5');

  await page.getByRole('button', { name: '複製' }).click();
  await expect(page.getByTestId('object-row-2')).toBeVisible();
  const duplicateId = await page.getByTestId('object-row-2').getAttribute('data-object-id');
  expect(duplicateId).toBeTruthy();
  expect(originalIds).not.toContain(duplicateId);
  await page.getByTestId('position-x').fill('2.5');
  await page.getByTestId('object-row-0').click();
  await expect(page.getByTestId('position-x')).toHaveValue('-1.5');
  await page.getByTestId('object-row-1').click();
  await expect(page.getByTestId('position-x')).toHaveValue(String(Number(secondPositionBefore.x.toFixed(2))));
  await page.getByTestId('object-row-2').click();
  await page.getByRole('button', { name: '削除' }).click();
  await expect(page.getByTestId('object-row-2')).toHaveCount(0);
  await page.getByTestId('save-garden').click();
  await expect(page.getByTestId('save-status')).toHaveText('保存済み');
  const stored = await saveGardenArtifact(request, id, 'garden-independent.json');
  expect(stored.objects).toHaveLength(2);
  expect(stored.objects.map((object) => object.id)).toEqual(originalIds);
  expect(stored.objects[0].position.x).toBe(-1.5);
  expect(stored.objects[1].position).toEqual(secondPositionBefore);
  expect(new Set(stored.objects.map((object) => object.id)).size).toBe(2);
  await expect(page.getByTestId('model-loaded')).toHaveText('読み込み済み: 2 / 2');
});

test('C. 不正な寸法と配置位置を拒否し既存庭を維持', async ({ page, request }) => {
  await page.goto('/');
  const invalidCreate = await request.post(`${apiBase}/gardens`, { data: { name: 'invalid size', width: 51, depth: 8 } });
  expect(invalidCreate.status()).toBe(400);

  const id = await createGarden(page, `E2E validation ${Date.now()}`);
  await placeTree(page);
  await page.getByTestId('save-garden').click();
  await expect(page.getByTestId('save-status')).toHaveText('保存済み');
  const before = await gardenJson(request, id);
  const invalidDocument = structuredClone(before);
  invalidDocument.objects[0].position.x = invalidDocument.width / 2 + 1;
  const rejected = await request.put(`${apiBase}/gardens/${id}`, { data: invalidDocument });
  expect(rejected.status()).toBe(400);
  expect(await gardenJson(request, id)).toEqual(before);
});

test('D. 保存失敗後の編集保持と再試行', async ({ page, request }) => {
  const id = await createGarden(page, `E2E retry ${Date.now()}`);
  await placeTree(page);
  await page.getByTestId('position-x').fill('1.2');
  await page.route(`**/api/gardens/${id}`, async (route) => {
    if (route.request().method() === 'PUT') await route.abort('failed');
    else await route.continue();
  });
  await page.getByTestId('save-garden').click();
  await expect(page.getByRole('alert')).toContainText('サーバーへ接続できませんでした');
  await expect(page.getByTestId('save-status')).toHaveText('未保存の変更');
  await expect(page.getByTestId('position-x')).toHaveValue('1.2');
  expect((await gardenJson(request, id)).revision).toBe(0);
  await page.unroute(`**/api/gardens/${id}`);
  await page.getByTestId('save-garden').click();
  await expect(page.getByTestId('save-status')).toHaveText('保存済み');
  expect((await gardenJson(request, id)).objects[0].position.x).toBe(1.2);
});

test('E. 古いrevisionの保存を競合として拒否しローカル編集を維持', async ({ page, request }) => {
  const id = await createGarden(page, `E2E conflict ${Date.now()}`);
  await placeTree(page);
  await page.getByTestId('save-garden').click();
  await expect(page.getByTestId('save-status')).toHaveText('保存済み');

  await page.getByTestId('position-x').fill('2');
  const serverDocument = await gardenJson(request, id);
  const competingDocument = structuredClone(serverDocument);
  competingDocument.objects[0].position.z = 1.25;
  const competingSave = await request.put(`${apiBase}/gardens/${id}`, { data: competingDocument });
  expect(competingSave.ok()).toBeTruthy();

  await page.getByTestId('save-garden').click();
  await expect(page.getByRole('alert')).toContainText('別の保存結果と競合しました');
  await expect(page.getByTestId('save-status')).toHaveText('未保存の変更');
  await expect(page.getByTestId('position-x')).toHaveValue('2');
  const serverAfterConflict = await gardenJson(request, id);
  expect(serverAfterConflict.revision).toBe(serverDocument.revision + 1);
  expect(serverAfterConflict.objects[0].position.z).toBe(1.25);
  await saveGardenArtifact(request, id, 'garden-conflict.json');
});
